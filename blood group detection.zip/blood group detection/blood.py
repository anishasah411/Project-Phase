import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# Create white image
image = np.full((750, 1280, 3), 255, dtype=np.uint8)
pil_image = Image.fromarray(image)
draw = ImageDraw.Draw(pil_image)
font = ImageFont.truetype("arial.ttf", 40)
text = "BLOOD GROUP DETECTION"

# Get text size and position
text_width, text_height = draw.textbbox((0, 0), text, font=font)[2:]
x, y = (1280 - text_width) // 2, 20

# Draw red background and white text
draw.rectangle([x - 10, y - 5, x + text_width + 10, y + text_height + 5], fill="red")
draw.text((x, y), text, fill="white", font=font)

# Add thick orange border below the text
border_height = 15
draw.rectangle([x - 10, y + text_height + 5, x + text_width + 10, y + text_height + 5 + border_height], fill="orange")

# Define spacing before the black frame starts
padding = 50
frame_start_y = y + text_height + 5 + border_height + padding

# Add a black frame starting below the text
frame_thickness = 10
frame_x1, frame_y1, frame_x2, frame_y2 = 50, frame_start_y, 1250, 625
draw.rectangle([frame_x1, frame_y1, frame_x2, frame_y2], outline="ORANGE", width=frame_thickness)

# Add "IMAGE DISPLAY BAR" at the top center of the main frame
display_text = "IMAGE DISPLAY BAR"
display_font = ImageFont.truetype("arialbd.ttf", 24)
text_width, text_height = draw.textbbox((0, 0), display_text, font=display_font)[2:]
text_x = frame_x1 + (frame_x2 - frame_x1 - text_width) // 2
text_y = frame_y1 + 10  # 10 pixels padding from the top of the frame
draw.text((text_x, text_y), display_text, fill="black", font=display_font)

# Add a vertical gray panel inside the left frame for buttons
left_panel_x1 = frame_x1 + 10
left_panel_x2 = frame_x1 + 240
left_panel_y1 = frame_y1 + 10
left_panel_y2 = frame_y2 - 10
draw.rectangle([left_panel_x1, left_panel_y1, left_panel_x2, left_panel_y2], fill="gray")

# Add buttons inside the left panel with gray background
button_font = ImageFont.truetype("arialbd.ttf", 20)
buttons = [
    "Select Blood Image", " GRAY SCALE", "Thresholding", "Complemented Image",
    "Edge Detection", "Split Images", "Quantification", "Clear All"
]
button_x, button_y = left_panel_x1 + 10, left_panel_y1 + 20  # Position inside gray panel
button_width, button_height, button_spacing = 200, 40, 15

for button in buttons:
    draw.rectangle([button_x, button_y, button_x + button_width, button_y + button_height], fill="darkgray")
    text_width, text_height = draw.textbbox((0, 0), button, font=button_font)[2:]
    text_x = button_x + (button_width - text_width) // 2
    text_y = button_y + (button_height - text_height) // 2
    draw.text((text_x, text_y), button, fill="white", font=button_font)
    button_y += button_height + button_spacing
    if button_y + button_height > left_panel_y2:
        break

# Add a horizontal frame at the bottom inside the main frame
horizontal_frame_x1 = frame_x1 + 240
horizontal_frame_x2 = frame_x2 - 10
horizontal_frame_y1 = frame_y2 - (frame_y2 - frame_y1) // 4
horizontal_frame_y2 = frame_y2 - 10
draw.rectangle([horizontal_frame_x1, horizontal_frame_y1, horizontal_frame_x2, horizontal_frame_y2], outline="ORANGE", width=frame_thickness)

# Add a status bar on the right side of the horizontal frame
status_bar_x1 = horizontal_frame_x2 - 150
status_bar_x2 = horizontal_frame_x2 - 10
status_bar_y1 = horizontal_frame_y1 + 10
status_bar_y2 = horizontal_frame_y2 - 10
draw.rectangle([status_bar_x1, status_bar_y1, status_bar_x2, status_bar_y2], fill="lightgray")

# Add text to the status bar
status_text = "STATUS "
status_font = ImageFont.truetype("arialbd.ttf", 20)
text_width, text_height = draw.textbbox((0, 0), status_text, font=status_font)[2:]
text_x = status_bar_x1 + (status_bar_x2 - status_bar_x1 - text_width) // 2
text_y = status_bar_y1 + (status_bar_y2 - status_bar_y1 - text_height) // 2
draw.text((text_x, text_y), status_text, fill="black", font=status_font)

# Show image
cv2.imshow("Project Workspace", cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR))
cv2.waitKey(0)
cv2.destroyAllWindows()

